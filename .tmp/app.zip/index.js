import { default as checkStatus_1_0 } from './functions/check-status/1.0';
import { default as fetchJsonVariable_1_0 } from './functions/fetch-json-variable/1.0';
import { default as generateToken_1_0 } from './functions/generate-token/1.0';
import { default as retrieveTextTranslation_1_0 } from './functions/retrieve-text-translation/1.0';
import { default as translateDocument_1_0 } from './functions/translate-document/1.0';
import { default as translateText_1_0 } from './functions/translate-text/1.0';

const fn = {
  "checkStatus 1.0": checkStatus_1_0,
  "fetchJsonVariable 1.0": fetchJsonVariable_1_0,
  "generateToken 1.0": generateToken_1_0,
  "retrieveTextTranslation 1.0": retrieveTextTranslation_1_0,
  "translateDocument 1.0": translateDocument_1_0,
  "translateText 1.0": translateText_1_0,
};

export default fn;
