import { default as fetchJsonVariable_1_0 } from './functions/fetch-json-variable/1.0';
import { default as https2_1_0 } from './functions/https2/1.0';
import { default as jsonBuilder_1_0 } from './functions/json-builder/1.0';
import { default as objectExpression_1_0 } from './functions/object-expression/1.0';
import { default as sayHello_1_0 } from './functions/say-hello/1.0';
import { default as translateDocument_1_0 } from './functions/translate-document/1.0';

const fn = {
  "fetchJsonVariable 1.0": fetchJsonVariable_1_0,
  "https2 1.0": https2_1_0,
  "jsonBuilder 1.0": jsonBuilder_1_0,
  "objectExpression 1.0": objectExpression_1_0,
  "sayHello 1.0": sayHello_1_0,
  "translateDocument 1.0": translateDocument_1_0,
};

export default fn;
