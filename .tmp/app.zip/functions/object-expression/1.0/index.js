const objectExpression = async () => {

}

export default objectExpression;